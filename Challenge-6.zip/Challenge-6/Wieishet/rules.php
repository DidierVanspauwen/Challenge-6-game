<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regels</title>
    <link rel="stylesheet" href="rules.css">
</head>
<body>

<div>

    <!-- Home Button -->

    <div class="homeBtn">
    <h3><a href="index.php">HOME</a><br><br><h3>
    </div>


    <h1>SPELREGELS<h1>

    <h2>DE REGELS ZIJN SIMPEL. JE MOET
    RADEN WELK PERSONAGE DE
    COMPUTER HEEFT GEKOZEN.<br> DIT DOE
    JE RADEN MET BEHULP VAN HOKJES
    DAT JE KAN AANVINKEN<br> <h2>
<br>
    <h3>JE MAG ZELF NADAT DE VRAAG IS 
BEANTWOORD ZOVEEL KAARTJES ALS
JE WILT OMDRAAIEN. OF DAT EEN SLIM
IDEE IS HET TWEEDE, MAAR DAT MAG
JE ZELF UITVOGELEN.<h3>

<h4>ALS JE EENMAAL DENKT TE WETEN WAT
DE KAART IS KAN JE OP HET HOKJE
DAT DOORGESTREEPT IS OM TE RADEN
WELK PERSONAGE DE COMPUTER
HEEFT GEKOZEN. ALS JE HET CORRECT
HEBT, HEB JE GEWONNEN. ANDERS
MOET JE OPNIEUW HET SPEL SPELEN<h4>







</body>
</html>