   <link rel="stylesheet" href="index.css">
</head>
<body>

    <div id="r1">Online</div>
    <div id="r2">"Who is it?"</div><br><br> 

    <div id="r3"><a href="play.php"> Play!</a></div><br><br>

    <div id="r4"><a href="rules.php">Regels</a></div>

</body>
</html>